rates = [
    {
        currency: 'USD',
        rate: 107.74,
        comission: 75
    },
    {
        currency: 'EUR',
        rate: 114.31,
        comission: 75
    },
    {
        currency: 'TRY',
        rate: 3.11,
        comission: 75
    },
    {
        currency: 'PLN',
        rate: 26.43,
        comission: 50
    },
    {
        currency: 'AED',
        rate: 29.34,
        comission: 50
    },
    {
        currency: 'RUR',
        rate: 1,
        comission: 50
    },
    {
        currency: 'TG',
        rate: 0.09333333,
        comission: 50
    },
    {
        currency: 'Diamonds',
        rate: 2.07142857,
        comission: 50
    },
    {
        currency: 'Coins',
        rate: 0.552906977,
        comission: 50
    },
    {
        currency: 'Pack',
        rate: 37,
        comission: 50
    },
    {
        currency: 'Кристаллы',
        rate: 1.41666667,
        comission: 50
    },
    {
        currency: 'INR',
        rate: 1.28,
        comission: 50
    },
    {
        currency: 'GBP',
        rate: 136.64,
        comission: 50
    },
    {
        currency: 'BRL',
        rate: 18,
        comission: 50
    },
    {
        currency: 'SAR',
        rate: 27.52,
        comission: 50
    }
]