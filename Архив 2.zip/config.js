export {profitPercentage}

const profitPercentage = 0.0035;
